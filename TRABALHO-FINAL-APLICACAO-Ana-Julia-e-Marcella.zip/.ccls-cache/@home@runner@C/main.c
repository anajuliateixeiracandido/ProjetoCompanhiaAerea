#include <stdio.h>

int main(void) {
  printf("Hello World\n");
  return 0;
}