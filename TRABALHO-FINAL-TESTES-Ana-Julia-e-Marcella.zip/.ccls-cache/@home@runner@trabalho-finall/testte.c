#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CHAR 100
#define MAX_PASSAGEIROS 100

typedef struct {
  char cpf[MAX_CHAR];
  char nome[MAX_CHAR];
  char endereco[MAX_CHAR];
  char telefone[MAX_CHAR];
  char numPassagem[MAX_CHAR];
  char numPoltrona[MAX_CHAR];
  char numVoo[MAX_CHAR];
  char horario[MAX_CHAR];
} Passageiro;

Passageiro* readFile() {
  FILE* arquivo = fopen("src/database/passageiros.txt", "r");
  if (arquivo == NULL) {
    printf("Erro ao abrir o arquivo.\n");
    return NULL;
  }

  Passageiro* passageiros = malloc(sizeof(Passageiro) * MAX_PASSAGEIROS);
  if (passageiros == NULL) {
    printf("Erro ao alocar memória.\n");
    fclose(arquivo);
    return NULL;
  }

  char linha[MAX_CHAR];
  Passageiro passageiro;
  int passageirosCount = 0;

  while (fgets(linha, MAX_CHAR, arquivo)) {
    if (linha[0] == '\n') {
      passageiros[passageirosCount++] = passageiro;
      memset(&passageiro, 0, sizeof(Passageiro));
    } else {
      char chave[MAX_CHAR], valor[MAX_CHAR];
      sscanf(linha, "%[^:]:%s", chave, valor);

      if (strcmp(chave, "CPF") == 0) {
        strcpy(passageiro.cpf, valor);
      } else if (strcmp(chave, "Nome") == 0) {
        strcpy(passageiro.nome, valor);
      } else if (strcmp(chave, "Endereco") == 0) {
        strcpy(passageiro.endereco, valor);
      } else if (strcmp(chave, "Telefone") == 0) {
        strcpy(passageiro.telefone, valor);
      } else if (strcmp(chave, "Número da Passagem") == 0) {
        strcpy(passageiro.numPassagem, valor);
      } else if (strcmp(chave, "Número da Poltrona") == 0) {
        strcpy(passageiro.numPoltrona, valor);
      } else if (strcmp(chave, "Número do Voo") == 0) {
        strcpy(passageiro.numVoo, valor);
      } else if (strcmp(chave, "Horário") == 0) {
        strcpy(passageiro.horario, valor);
      }
    }
  }

  fclose(arquivo);

  return passageiros;
}

int main() {
  Passageiro* passageiros = readFile();
  if (passageiros == NULL) {
    printf("Erro ao ler o arquivo.\n");
    return 1;
  }

  // Utilize o array de passageiros

  free(passageiros);

  return 0;
}
