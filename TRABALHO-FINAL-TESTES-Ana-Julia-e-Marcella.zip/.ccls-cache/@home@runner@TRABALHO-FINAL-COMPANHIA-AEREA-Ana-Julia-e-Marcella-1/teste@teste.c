#include "../passageiros.h"
#include "unity.h"

void setUp(void) {
  // Configuração inicial antes de cada teste
}

void tearDown(void) {
  // Limpeza após cada teste
}

// TESTE - READFILE
void testReadFile_FileNotFound(void) {
    Passageiro passageiros[MAX_PASSAGEIROS];

    int result = readFile("BH-RIO-teste-notfound.txt", passageiros);
    TEST_ASSERT_EQUAL_INT(0, result);
}

void testReadFile_EmptyFile(void) {
  Passageiro passageiros[MAX_PASSAGEIROS];
  int result = readFile("BH-RIO-teste-empty.txt", passageiros);
  TEST_ASSERT_EQUAL_INT(0, result);
}

void testReadFile_PassageiroValido(void) {
  Passageiro passageiros[MAX_PASSAGEIROS];
  int result =
      readFile("BH-RIO.txt", passageiros);
  TEST_ASSERT_GREATER_OR_EQUAL(1, result);
  TEST_ASSERT_EQUAL_STRING("647.762.371-48", passageiros[0].cpf);
  TEST_ASSERT_EQUAL_STRING("Marcella Azevedo", passageiros[0].nome);
}


//TESTE - BUSCARPASSAGEIROPORNOME
void test_buscarPassageiroPorNome() {
  
    Passageiro passageiros[] = {
        {"Marcella Azevedo"},
        {"Ana Julia Almeida"},
        {"Vitor Cardoso"}
    };
   int result =
      readFile("BH-RIO.txt", passageiros);
    int numPassageiros = sizeof(passageiros) / sizeof(passageiros[0]);
 

    // Teste caso o passageiro seja encontrado
    Passageiro passageiroEncontrado = buscarPassageiroPorNome(passageiros, numPassageiros);
    TEST_ASSERT_TRUE_MESSAGE(strcmp("Passageiro não encontrado", passageiroEncontrado.nome) != 0, "O passageiro deve ser encontrado");

    // Teste caso o passageiro não seja encontrado
    Passageiro passageiroNaoEncontrado = buscarPassageiroPorNome(passageiros, numPassageiros);
    TEST_ASSERT_TRUE_MESSAGE(strcmp("Passageiro não encontrado", passageiroNaoEncontrado.nome) == 0, "O passageiro não deve ser encontrado");
}



//MAIN
int main() {
  UNITY_BEGIN();

  RUN_TEST(testReadFile_EmptyFile);
  RUN_TEST(testReadFile_PassageiroValido);
  RUN_TEST(testReadFile_FileNotFound);
   RUN_TEST(test_buscarPassageiroPorNome);

  return UNITY_END();
};