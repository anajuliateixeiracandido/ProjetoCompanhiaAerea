// assinatura

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#ifndef PASSAGEIROS_H
#define PASSAGEIROS_H

#define MAX_CHAR 100
#define MAX_PASSAGEIROS 10
#define MAX_ESPERA 5

typedef struct {

  char cpf[MAX_CHAR];
  char nome[MAX_CHAR];
  char endereco[MAX_CHAR];
  char telefone[MAX_CHAR];
  char numPassagem[MAX_CHAR];
  char numPoltrona[MAX_CHAR];
  char numVoo[MAX_CHAR];
  char horario[MAX_CHAR];
} Passageiro;

typedef struct {

  Passageiro passageiros[MAX_ESPERA];
  int numPassageiros;
} FilaEspera;


int readFile(char filePath[], Passageiro passageiros[]);
void setFile(char filePath[], Passageiro passageiros[], int numPassageiros);
Passageiro buscarPassageiroPorNome(Passageiro passageiros[], int numPassageiros);
Passageiro buscarPassageiroPorCpf(Passageiro passageiros[], int arraySize);
void adicionarPassageiroNoVoo(char voo[]);
void adicionarPassageiroNaFilaEspera(char voo[]);
void escreverArquivo(FILE *arquivo, Passageiro passageiro);
Passageiro lerNovoPassageiro(char voo[]);
void exibePassageiros(Passageiro passageiros[]);
void exibirListaDeEspera(const char *voo);
void excluirPassageiroDaLista(char filePath[], Passageiro passageiro, int numPassageiros);


#endif