#include "passageiros.h"


// LER ARQUIVOS
int readFile(char filePath[], Passageiro passageiros[]) {

	FILE *arquivo = fopen(filePath, "r");

	if (arquivo == NULL) {

		printf("Erro ao abrir o arquivo.\n");
		return 0;
	}

	char linha[MAX_CHAR];
	int passageirosCount = 0;

	while (fgets(linha, MAX_CHAR, arquivo)) {

		if(strstr(linha, "CPF: ") != NULL) {

			sscanf(linha, "CPF: %s", passageiros[passageirosCount].cpf);

			fgets(linha, MAX_CHAR, arquivo);
			sscanf(linha, "Nome: %[^\n]", passageiros[passageirosCount].nome);

			fgets(linha, MAX_CHAR, arquivo);
			sscanf(linha, "Endereço: %[^\n]", passageiros[passageirosCount].endereco);

			fgets(linha, MAX_CHAR, arquivo);
			sscanf(linha, "Telefone: %[^\n]", passageiros[passageirosCount].telefone);

			fgets(linha, MAX_CHAR, arquivo);
			sscanf(linha, "Número da Passagem: %[^\n]", passageiros[passageirosCount].numPassagem);

			fgets(linha, MAX_CHAR, arquivo);
			sscanf(linha, "Número da Poltrona: %[^\n]", passageiros[passageirosCount].numPoltrona);

			fgets(linha, MAX_CHAR, arquivo);
			sscanf(linha, "Voo: %[^\n]", passageiros[passageirosCount].numVoo);

			fgets(linha, MAX_CHAR, arquivo);
			sscanf(linha, "Horário: %[^\n]", passageiros[passageirosCount].horario);

			passageirosCount++;

			if (passageirosCount == MAX_PASSAGEIROS) break;
		}
	}

	fclose(arquivo);

	return passageirosCount;
}

// BUSCAR PASSAGEIRO POR NOME
Passageiro buscarPassageiroPorNome(Passageiro passageiros[], int numPassageiros) {

	char searchTerm[MAX_CHAR];

	printf("Digite o nome do passageiro: ");
	scanf(" %[^\n]", searchTerm);

	if (passageiros && !(searchTerm[0] == '\0')) {

		for (int i = 0; i < numPassageiros; i++) {

			if (!strcmp(passageiros[i].nome, searchTerm)) return passageiros[i];
		}
	}

	Passageiro passageiroDefault;
	return passageiroDefault;
}

// BUSCAR PASSAGEIRO POR CPF
Passageiro buscarPassageiroPorCpf(Passageiro passageiros[], int arraySize) {

	char searchTerm[MAX_CHAR];


	printf("Digite o CPF do passageiro: ");
	scanf("%s", searchTerm);

	if (passageiros && !(searchTerm[0] == '\0')) {

		for (int i = 0; i < arraySize; i++) {

			if (!strcmp(passageiros[i].cpf, searchTerm)) return passageiros[i];
		}
	}

	Passageiro passageiroDefault;

	strcpy(passageiroDefault.cpf, "N/A");

	return passageiroDefault;
}


Passageiro lerNovoPassageiro(char voo[]);

void escreverArquivo(FILE *arquivo, Passageiro passageiro);

// ADICIONAR PASSAGEIRO
void adicionarPassageiroNoVoo(char voo[]) {

	FILE *arquivo;
	Passageiro passageiro = lerNovoPassageiro(voo);

	if ((arquivo = fopen(voo, "a")) == NULL) {

		printf("Erro na abertura do arquivo.\n");
		exit(1); // Finaliza a execucao do programa com status (1)
	}

	escreverArquivo(arquivo, passageiro);
}

//ADICIONAR PASSAGEIRO NA FILA DE ESPERA
void adicionarPassageiroNaFilaEspera(char voo[]) {

	FILE *arquivo;
	Passageiro passageiro = lerNovoPassageiro(voo);

	if ((arquivo = fopen(voo, "a")) == NULL) {

		printf("Erro na abertura do arquivo.\n");
		exit(1); // Finaliza a execucao do programa com status (1)
	}
	escreverArquivo(arquivo, passageiro);
}

// ESCREVER ARQUIVO
void escreverArquivo(FILE *arquivo, Passageiro passageiro) {

	// O fseek vai buscar uma posicao do arquivo, e partir dela, voltar ou avancar
	// X posicoes e escrever o novo valor. No caso que eu fiz, ele vai para o fim
	// do arquivo (SEEK_END) e, a partir dele, movimenta 0 caracteres, e escreve o
	// novo valor.
	fseek(arquivo, 0, SEEK_END);
	fprintf(arquivo, "\nCPF: %s\n", passageiro.cpf);
	fprintf(arquivo, "Nome: %s\n", passageiro.nome);
	fprintf(arquivo, "Endereço: %s\n", passageiro.endereco);
	fprintf(arquivo, "Telefone: %s\n", passageiro.telefone);
	fprintf(arquivo, "Número da Passagem: %s\n", passageiro.numPassagem);
	fprintf(arquivo, "Número da Poltrona: %s\n", passageiro.numPoltrona);
	fprintf(arquivo, "Voo: %s\n", passageiro.numVoo);
	fprintf(arquivo, "Horário: %s\n", passageiro.horario);
	fclose(arquivo);
}

// LER PASSAGEIRO
Passageiro lerNovoPassageiro(char voo[]) {

	Passageiro novoPassageiro;

	printf("CPF: ");
	scanf(" %[^\n]", novoPassageiro.cpf);

	printf("Nome: ");
	scanf(" %[^\n]", novoPassageiro.nome);

	printf("Endereço: ");
	scanf(" %[^\n]", novoPassageiro.endereco);

	printf("Telefone: ");
	scanf(" %[^\n]", novoPassageiro.telefone);

	printf("Número da Passagem: ");
	scanf(" %[^\n]", novoPassageiro.numPassagem);

	printf("Número da Poltrona: ");
	scanf(" %[^\n]", novoPassageiro.numPoltrona);

	printf("Horário: ");
	scanf(" %[^\n]", novoPassageiro.horario);

	strcpy(novoPassageiro.numVoo, voo);

	return novoPassageiro;
}

// EXIBIR PASSAGEIROS
void exibePassageiros(Passageiro passageiros[]) {

	for (int i = 0; i < MAX_PASSAGEIROS; i++) {

		printf("\nCPF: %s\n", passageiros[i].cpf);
		printf("Nome: %s\n", passageiros[i].nome);
		printf("Endereco: %s\n", passageiros[i].endereco);
		printf("Telefone: %s\n", passageiros[i].telefone);
		printf("Número da Passagem: %s\n", passageiros[i].numPassagem);
		printf("Número da Poltrona: %s\n", passageiros[i].numPoltrona);
		printf("Voo: %s\n", passageiros[i].numVoo);
		printf("Horário: %s\n", passageiros[i].horario);
	}
}

// EXIBIR LISTA DE ESPERA
void exibirListaDeEspera(const char *voo) {

	char nomeArquivo[30];
	sprintf(nomeArquivo, "%s-FDE.txt", voo);

	FILE *arquivo = fopen(nomeArquivo, "r");

	if (arquivo == NULL) {

		printf("Erro ao abrir o arquivo.\n");
		return;
	}

	char linha[MAX_CHAR];

	while (fgets(linha, sizeof(linha), arquivo) != NULL) printf("%s", linha);

	fclose(arquivo);
}

// EXCLUIR PASSAGEIRO
void excluirPassageiroDaLista(char filePath[], Passageiro passageiro, int numPassageiros) {

	FILE *arquivo = fopen(filePath, "r");

	if (arquivo == NULL) {

		printf("Erro ao abrir o arquivo.\n");
		return;
	}

	// -------------------------------------------------------------------------------------------- //

	FILE *arquivoTemp = fopen("temp.txt", "w");

	if (arquivoTemp == NULL) {

		printf("Erro ao abrir o arquivo.\n");
		return;
	}

	char linha[MAX_CHAR];

	while (fgets(linha, sizeof(linha), arquivo) != NULL) {

		// if found cpf
		if (strstr(linha, passageiro.cpf) != NULL) {

			// skip 7 lines
			for (int i = 0; i < 7; i++) fgets(linha, sizeof(linha), arquivo);

		} 
		else fprintf(arquivoTemp, "%s", linha);
	}

	fclose(arquivo);
	fclose(arquivoTemp);

	// Rename and remove
	remove(filePath);
	rename("temp.txt", filePath);
	
	// -------------------------------------------------------------------------------------------- //

	// Se o passageiro excluído estava na lista normal, então realocar os passageiros da lista de espera
	if(strstr(filePath, "-FDE.txt") == NULL) {

		// Get lista de espera
		char filePathFDE[30];
		strcpy(filePathFDE, filePath);

		filePathFDE[strlen(filePathFDE) - 4] = '\0';
		strcat(filePathFDE, "-FDE.txt");

		Passageiro passageirosFDE[MAX_ESPERA];

		int listaEspera = readFile(filePathFDE, passageirosFDE);

		// ----------------------------------------------------- //

		if(listaEspera > 0) {

			// Get passageiro da lista de espera
			Passageiro passageiroFDE = passageirosFDE[0];

			// Reconstruir arquivo da lista normal com o passageiro da lista de espera
			FILE *arquivo = fopen(filePath, "a");

			if (arquivo == NULL) {

				printf("Erro ao abrir o arquivo.\n");
				return;
			}

			fprintf(arquivo, "\nCPF: %s\n", passageiroFDE.cpf);
			fprintf(arquivo, "Nome: %s\n", passageiroFDE.nome);
			fprintf(arquivo, "Endereco: %s\n", passageiroFDE.endereco);
			fprintf(arquivo, "Telefone: %s\n", passageiroFDE.telefone);
			fprintf(arquivo, "Número da Passagem: %s\n", passageiroFDE.numPassagem);
			fprintf(arquivo, "Número da Poltrona: %s\n", passageiroFDE.numPoltrona);
			fprintf(arquivo, "Voo: %s\n", passageiroFDE.numVoo);
			fprintf(arquivo, "Horário: %s\n", passageiroFDE.horario);

			fclose(arquivo);

			// ----------------------------- //

			// Excluir passageiro da lista de espera
			excluirPassageiroDaLista(filePathFDE, passageiroFDE, listaEspera);
		}
	}
}